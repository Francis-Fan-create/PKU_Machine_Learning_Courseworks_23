All of the codes are written in matlab.
Data and corresponding code using them are saved under same folder.
RF: Random Forest
Bagging: Bootstrap Aggregating